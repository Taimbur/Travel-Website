import React, { useState, useContext } from "react";
import { Container, Col, Row, Form, FormGroup } from "reactstrap";
import loginImg from "../assets/img/register.jpg";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "../utils/config";
import "../style/Register.css";

import AppContext from "../context/authContext";

const Register = () => {
  const navi = useNavigate();
  const [credentials, setCredentials] = useState({
    FullName: "",
    Email: "",
    Password: "",
  });

  const handleChange = (e) => {
    setCredentials((prev) => ({ ...prev, [e.target.id]: e.target.value }));
  };

  const { loadData } = useContext(AppContext);

  const handleClick = async (e) => {
    e.preventDefault();
    const { Email, FullName, Password } = credentials;

    try {
      const res = await fetch(`${BASE_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ FullName, Email, Password }),
      });
      const result = await res.json();

      if (!res.ok) {
        alert(result.message);
      }

      alert(result.message);

      navi("/Login");
      loadData("Add_user", { newUser: { result } });
    } catch (error) {
      alert("something went wrong");
    }
  };

  return (
    <section>
      <Container>
        <Row>
          <Col lg="6" className="mt-5 my-5  ">
            <img src={loginImg} alt="register" className="w-75 mt-5 my-5" />
          </Col>

          <Col lg="6" className="form-r">
            <h1 className=" mt-5">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="100"
                height="100"
                fillRule="currentColor"
                className="bi bi-person-circle"
                viewBox="0 0 16 16"
              >
                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                <path
                  fillRule="evenodd"
                  d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"
                />
              </svg>
            </h1>
            <span className="text-capitalize text-center">register</span>

            <Form method="post" onSubmit={handleClick} className="mt-5">
              <FormGroup>
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  id="FullName"
                  value={credentials.FullName}
                  onChange={handleChange}
                />
              </FormGroup>

              <FormGroup>
                <input
                  type="email"
                  required
                  placeholder="Email"
                  id="Email"
                  onChange={handleChange}
                  value={credentials.Email}
                />
              </FormGroup>

              <FormGroup>
                <input
                  type="password"
                  required
                  placeholder="Password"
                  id="Password"
                  onChange={handleChange}
                  value={credentials.Password}
                />
              </FormGroup>

              <button
                className="btn btn-dark  w-75 mt-2 my-3 py-3   text-white"
                type="submit"
                onClick={handleClick}
              >
                {" "}
                Submit{" "}
              </button>
            </Form>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Register;
