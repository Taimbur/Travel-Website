import React from "react";
import "../style/Home.css";
import heroImg from "../assets/img/hero-img01.jpg";
import { useEffect } from "react";
import heroImg2 from "../assets/img/hero-img02.jpg";
import heroVideo from "../assets/img/hero-video.mp4";
import worldImg from "../assets/img/world.png";
import { Container, Row, Col } from "reactstrap";
import SearchBar from "../shared/SearchBar";
import ServiceList from "../services/ServiceList";
import FeatureTourList from "../components/FeatureTour/FeatureTourList";
import expericeImg from "../assets/img/exprience.png";
import Masonryy from "../components/image-gallery/masonryy";
import Tetimonals from "../components/tesimonal/Tetimonals";
import Newsletter from "../shared/Newsletter";
const Home = () => {
  useEffect(() => {
  
    window.scrollTo(0,0)
      
    }, [])
  return (
    <>
      <section>
        <Container className="my-5">
          <Row>
            <Col lg="6">
              <div className="hero__content">
                <div className="hero__subtitle d-flex align-content-between">
                  <h5 className="service__subtitle">know before you go</h5>
                  <img src={worldImg} alt="world" />
                </div>
                <h1 className="text-capitalize">
                  travel open doors of{" "}
                  <span className="highlight text-uppercase">memories</span>
                </h1>
                <p>
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                  Asperiores tenetur rem nisi, animi laborum temporibus.
                  Exercitationem blanditiis animi quae officia molestiae aliquam
                  quod quo, qui iure eligendi mollitia aspernatur adipisci?
                </p>
              </div>
            </Col>
            <Col lg="2">
              <div className="hero__img-box ">
                <img src={heroImg} alt="side" />
              </div>
            </Col>
            <Col lg="2">
              <div className="hero__img-box mt-4">
                <video src={heroVideo} alt="video" controls />
              </div>
            </Col>
            <Col lg="2">
              <div className="hero__img-box mt-5">
                <img src={heroImg2} alt="side" />
              </div>
            </Col>
            <SearchBar />
          </Row>
        </Container>
      </section>

      {/* new seceton begin here */}

      <section>
        <Container>
          <Row>
            <Col lg="3">
              <h5 className="service__subtitle">what we serve</h5>
              <h2 className="service__title">we provide best service</h2>
            </Col>
            <ServiceList />
          </Row>
        </Container>
      </section>

      {/* service section service end */}

      {/* featured tourlist */}

      <section>
        <Container className="my-5">
          <Row>
            <Col lg="3 my-5">
              <h5 className="service__subtitle">expolre</h5>
              <h2 className="service__title">make some memories</h2>
            </Col>
          </Row>
          <Row>
            <FeatureTourList />
          </Row>
        </Container>
      </section>

      {/* expirence section start */}
      <Container>
        <Row>
          <Col lg="6">
            <h6 className="service__subtitle">experience</h6>
            <div className="experience__content">
              <h2 className="service__title">
                with our all experience <br /> we will serve you best
              </h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere
                quas labore soluta reiciendis, sint nulla quasi est itaque
                sapiente deleniti? Consectetur eius dignissimos at fugiat,
                nostrum architecto iusto itaque esse!
              </p>
            </div>

            <div className="counter__wrapper gap-2 d-flex align-content-center justify-content-center">
              <div className="counter__box">
                <span>10k + </span>
                <h5>succesful trip</h5>
              </div>
              <div className="counter__box">
                <span>1k + </span>
                <h5>regular clients</h5>
              </div>
              <div className="counter__box">
                <span>5 year </span>
                <h5>expirence</h5>
              </div>
            </div>
          </Col>

          <Col lg="6">
            <div className="exprience__img">
              <img src={expericeImg} alt="exprienceimg" />
            </div>
          </Col>
        </Row>
      </Container>

      {/* exprience section end here */}
      {/* gallery section start */}

      <section>
        <Container>
          <Row>
            <Col lg="3">
              <h5 className="service__subtitle">gallery</h5>
              <h2 className="service__title">visit our gallery</h2>
            </Col>
            <Col lg="9" className="gallery__img">
              <Masonryy />
            </Col>
          </Row>
        </Container>
      </section>
      {/* gallery section end */}

      {/* tesimoney begin here */}
      <section className="mx-2 my-5">
        <Container className="mt-3">
          <Row>
            <Col lg="12">
              <h5 className="service__subtitle">Testimonial</h5>
              <h2 className="service__title">What our client say about us</h2>
            </Col>
            <Col lg="12">
              <Tetimonals />
            </Col>
          </Row>
        </Container>
      </section>
      {/* tesimonal end */}

      {/* Newsletter begin here */}
      <section className="bg-light mt-5 mb-4">
        <Container className="mt-5 bg-primary h-50">
          <Row>
            <Col lg="6">
              <h5 className="text-uppercase mt-5 m-2 text-white hi ">
                subscribe now to get travling information.
              </h5>
              <h5 className="nl-subs">
                <input
                  type="text"
                  name=""
                  id=""
                  placeholder=" Your Email "
                  className="text-center text-dark  mt-3 py-2 px-5"
                />{" "}
                <span>
                  <button className="btn btn-outline-warning text-white text-uppercase mb-2">
                    Subscribe
                  </button>
                </span>
              </h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                reiciendis temporibus?
              </p>
            </Col>
            <Col lg="6" className="mr-5">
              <Newsletter />
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
 
  
};

export default Home;
