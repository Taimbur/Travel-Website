import React, { useEffect, useState } from "react";
import CommonSection from "../shared/CommonSection";
import SearchBar from "../shared/SearchBar";
import TourCard from "../shared/Tour-Card";
import { Container, Row, Col } from "reactstrap";

import "../style/Tours.css";
import Newsletter from "../shared/Newsletter";
import useFetch from "../hooks/usefetch";
import { BASE_URL } from "../utils/config";

const Tours = () => {
  const [pageCount, setpageCount] = useState(0);
  const [page, setpage] = useState(0);
  const { data: tours } = useFetch(`${BASE_URL}/tours?page=${page}`);
  const { data: tourcount } = useFetch(`${BASE_URL}/tours/get/TourCount`);

  useEffect(() => {
    const pages = Math.ceil(tourcount / 8);
    setpageCount(pages);
    window.scrollTo(0, 0);
  }, [page, tourcount, tours]);

  return (
    <>
      <CommonSection title={"All Tours"} />
      <section>
        <Container>
          <Row>
            <SearchBar />
          </Row>
        </Container>
      </section>

      <section className="my-4">
        <Container>
          <Row>
            {tours?.map((tour) => (
              <Col lg="6" md="6" sm="6" className="my-3" key={tour._id}>
                {" "}
                <TourCard tour={tour} />
              </Col>
            ))}
          </Row>

          <Col lg="3">
            <div className="pagination d-flex align-items-center justify-content-center my-4 ">
              {[...Array(pageCount).keys()].map((number) => (
                <span
                  key={number}
                  onClick={() => setpage(number)}
                  className={page === number ? "active__page" : " "}
                >
                  {number + 1}
                </span>
              ))}
            </div>
          </Col>
        </Container>
      </section>

      <section className="bg-light mt-5  mb-4">
        <Container className="mt-5 bg-primary h-50">
          <Row>
            <Col lg="6">
              <h5 className="text-uppercase mt-5 m-2 text-white hi ">
                subscribe now to get travling information.
              </h5>
              <h5 className="nl-subs">
                <input
                  type="text"
                  name=""
                  id=""
                  placeholder=" Your Email "
                  className="text-center text-dark  mt-3 py-2 px-5"
                />{" "}
                <span>
                  <button className="btn btn-outline-warning text-white text-uppercase mb-2">
                    Subscribe
                  </button>
                </span>
              </h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                reiciendis temporibus?
              </p>
            </Col>
            <Col lg="6" className="mr-5">
              <Newsletter />
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Tours;
