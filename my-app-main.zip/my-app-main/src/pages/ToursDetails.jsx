import React, { useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../style/TourDetails.css";
import { Container, Row, Col } from "reactstrap";
import userImg from "../assets/img/user.jpg";
import Booking from "../components/Booking/Booking";
import Newsletter from "../shared/Newsletter";
import useFetch from "../hooks/usefetch";
import { BASE_URL } from "../utils/config";
import { useEffect } from "react";

const ToursDetails = () => {
  const [rdata, setRdata] = useState([]);

  let testing = JSON.parse(window.localStorage.getItem("User"));

  const navi = useNavigate;
  const { id } = useParams();
  const { data: tour, error } = useFetch(`${BASE_URL}/tours/${id}`);

  const {
    photo,
    address,
    title,
    desc,
    price,
    reviews,
    city,
    distance,
    maxGroupSize,
    avgRating,
  } = tour;

  const [inputValue, setinputValue] = useState(null);
  const msg = useRef("");

  const submitHandler = async (e) => {
    e.preventDefault();
    const reviewText = msg.current.value;
    if (!testing || testing === undefined || testing === null) {
      return alert("Login Please");
    }
    try {
      const reviewObj = {
        FullName: testing,
        reviewText,
        rating: inputValue,
      };
      const res = await fetch(`${BASE_URL}/reviews/${id}`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },

        user: "include",
        body: JSON.stringify(reviewObj),
      });
      const result = await res.json();
      if (!res.ok) {
        return alert(result.message);
      }

      alert(result.message);
      window.location.reload(true);
    } catch (error) {
      return alert("something went wrong kaam ni kr rha ha", navi("/tours"));
    }
  };

  const fetchUserData = () => {
    fetch(`${BASE_URL}/reviews`)
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setRdata(data.data);
      });
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchUserData();
  }, []);

  return (
    <>
      <section>
        <Container className="mt-5">
          {error && <h2>{error}</h2>}
          <Row>
            <Col lg="8">
              <img src={photo} alt="details" className="tour-main-img" />

              <div className="tour__info text-captilize">
                <h2>{title}</h2>
                <div className="d-flex align-content-center gap-5 ">
                  <i className="tour__ration align-content-center ">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fillRule="currentColor"
                      className="bi bi-star"
                      viewBox="0 0 16 16"
                    >
                      <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                    </svg>{" "}
                    {avgRating} <span>({reviews?.length})</span>
                  </i>

                  <span className="address_info justify-content-center align-content-center d-flex gap-2">
                    <i>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-people"
                        viewBox="0 0 16 16"
                      >
                        <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8Zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816ZM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0Zm3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
                      </svg>
                    </i>
                    <h5>{address}</h5>
                  </span>
                  <span className="address_info justify-content-center align-content-center d-flex gap-2">
                    <i>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-geo-alt-fill"
                        viewBox="0 0 16 16"
                      >
                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
                      </svg>
                    </i>
                    <h5>{distance}/km</h5>
                  </span>
                </div>

                <span className="d-flex gap-2">
                  <i>
                    {" "}
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fillRule="currentColor"
                      className="bi bi-geo-alt-fill"
                      viewBox="0 0 16 16"
                    >
                      <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
                    </svg>
                  </i>{" "}
                  {city}{" "}
                </span>
                <span className="d-flex gap-2">
                  <i>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fillRule="currentColor"
                      className="bi bi-coin"
                      viewBox="0 0 16 16"
                    >
                      <path d="M5.5 9.511c.076.954.83 1.697 2.182 1.785V12h.6v-.709c1.4-.098 2.218-.846 2.218-1.932 0-.987-.626-1.496-1.745-1.76l-.473-.112V5.57c.6.068.982.396 1.074.85h1.052c-.076-.919-.864-1.638-2.126-1.716V4h-.6v.719c-1.195.117-2.01.836-2.01 1.853 0 .9.606 1.472 1.613 1.707l.397.098v2.034c-.615-.093-1.022-.43-1.114-.9H5.5zm2.177-2.166c-.59-.137-.91-.416-.91-.836 0-.47.345-.822.915-.925v1.76h-.005zm.692 1.193c.717.166 1.048.435 1.048.91 0 .542-.412.914-1.135.982V8.518l.087.02z" />
                      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                      <path d="M8 13.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zm0 .5A6 6 0 1 0 8 2a6 6 0 0 0 0 12z" />
                    </svg>
                  </i>{" "}
                  ${price} /per person{" "}
                </span>

                <span className="d-flex gap-2">
                  <i>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fillRule="currentColor"
                      className="bi bi-people"
                      viewBox="0 0 16 16"
                    >
                      <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8Zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816ZM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0Zm3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
                    </svg>
                  </i>{" "}
                  {maxGroupSize}{" "}
                </span>

                <h5 className="desc text-uppercase">{desc}</h5>
              </div>

              {/* reviews section */}
              <div className="review__sec mt-5 align-content-start mb-5">
                <h4>
                  Reviews
                  <b> ({reviews?.length}Review)</b>
                </h4>
                <form onSubmit={submitHandler}>
                  <div className="d-flex align-content-center  justify-content-center review__rating ">
                    <i className="m-1" onClick={() => setinputValue(1)}>
                      <svg
                        xmlns="http://www.w onclick={setinputvalue={}}3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-star"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                      </svg>
                    </i>
                    <i className="m-1" onClick={() => setinputValue(2)}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-star"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                      </svg>
                    </i>
                    <i className="m-1" onClick={() => setinputValue(3)}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-star"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                      </svg>
                    </i>
                    <i className="m-1" onClick={() => setinputValue(4)}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-star"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                      </svg>
                    </i>
                    <i className="m-1" onClick={() => setinputValue(5)}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fillRule="currentColor"
                        className="bi bi-star"
                        viewBox="0 0 16 16"
                      >
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                      </svg>
                    </i>
                  </div>
                  <div className="review_in mb-5  border border-warning rounded-5 ">
                    <input
                      type="text"
                      ref={msg}
                      name=""
                      id=""
                      placeholder="Share Your Thoughts "
                      className="text-center text-dark border border-0  mt-3 py-2 px-3  w-75 rounded-5 "
                    />
                    <span>
                      <button
                        className="btn btn-warning btn-md text-white text-uppercase mb-2 px-3 py-2  rounded-5"
                        type="submit"
                      >
                        Submit
                      </button>
                    </span>
                  </div>
                </form>

                {rdata.length > 0 &&
                  rdata?.map((data,comments) => (
                    <ul key={comments} className="list-group border  rounded-5 text-capitalize naam">
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        <img src={userImg} alt="k" className="w-25 h-25" />
                        <span className="badge bg-warning rounded-pill  star  ">
                          {data.rating}

                          <i className="m-1 star">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              fillRule="currentColor"
                              className="bi bi-star"
                              viewBox="0 0 16 16"
                            >
                              <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                            </svg>
                          </i>
                        </span>
                      </li>
                      <li className="text-uppercase  text-decoration-none list-group p-2  text-bg-warning ">
                        {data.FullName}
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        <p>{data.createdAt.slice(0, 10)}</p>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        <p>{data.reviewText}</p>
                      </li>
                    </ul>
                  ))}

                {/* {console.log(rdata.reviewText)} */}
              </div>
            </Col>

            <Col lg="3" className="mt-5">
              <Booking tour={tour} />
            </Col>
          </Row>
        </Container>
      </section>

      <section className="bg-light mt-5 ">
        <Container className="mt-5 bg-primary h-50 news ">
          <Row>
            <Col lg="6">
              <h5 className="text-uppercase mt-5 m-2 text-white hi ">
                subscribe now to get travling information.
              </h5>

              <h5 className="nl-subs">
                <input
                  type="text"
                  name=""
                  id=""
                  placeholder=" Your Email "
                  className="text-center text-dark  mt-3 py-2 px-5"
                />{" "}
                <span>
                  <button className="btn btn-outline-warning text-white text-uppercase mb-2">
                    Subscribe
                  </button>
                </span>
              </h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                reiciendis temporibus?
              </p>
            </Col>
            <Col lg="6" className="mr-5">
              <Newsletter />
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default ToursDetails;
