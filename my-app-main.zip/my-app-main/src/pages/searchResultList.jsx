import React, { useState } from "react";
import CommonSection from "../shared/CommonSection";
import { Container, Row, Col } from "reactstrap";
import { useLocation } from "react-router-dom";

import TourCard from "../shared/Tour-Card";
const SearchResultList = () => {
  const location = useLocation();
  const [data] = useState(location.state);
 
  return (
    <>
      <CommonSection title={"Search Result"} />
      <section>
        <Container>
          <Row>
            {data.lenth === 0 ? (
              <h4>result of search not found</h4>
            ) : (
              data?.map((tour) => (
                <Col lg="3" className="mb-4">
                  <TourCard tour={tour._id} />
                </Col>
              ))
            )}
          </Row>
        </Container>
      </section>
    </>
  );
};

export default SearchResultList;
