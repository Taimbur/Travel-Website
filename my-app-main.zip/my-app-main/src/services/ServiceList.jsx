import React from "react";
import ServiceCard from "./ServiceCard";
import { Col } from "reactstrap";
import weatherImg from "../assets/img/weather.png";
import guideImg from "../assets/img/guide.png";
import customizationImg from "../assets/img/customization.png";

const ServiceData = [
  {
    imgUrl: weatherImg,
    title: "Calculate Weather",
    desc: "weather test ",
  },
  {
    imgUrl: guideImg,
    title: "Guide",
    desc: "weather test ",
  },
  {
    imgUrl: customizationImg,
    title: "Customization",
    desc: "weather test ",
  },
];

const ServiceList = () => {
  return ServiceData.map((item, index) => (
    <Col lg="3" key={index}>
      <ServiceCard item={item} />
    </Col>
  ));
};

export default ServiceList;
