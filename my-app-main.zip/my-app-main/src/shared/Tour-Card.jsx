import React from "react";

import { Card, CardBody } from "reactstrap";
import "../style/Tour-Card.css";
import { Link } from "react-router-dom";

const TourCard = ({ tour }) => {
  const { _id, title, photo, price, city, avgRating, reviews } = tour;
 
  return (
    <div className="tour__card ">
      <Card>
        <div className="tour__img">
          <img src={photo} alt="tourimg" />
          <span className="feature">Featuring</span>
        </div>

        <CardBody>
          <div className="card__top d-flex align-content-center justify-content-between mt-2">
            <span className="tour__location d-flex align-content-center gap-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fillRule="currentColor"
                className="bi bi-map"
                viewBox="0 0 16 16"
              >
                <path
                  fillRule="evenodd"
                  d="M15.817.113A.5.5 0 0 1 16 .5v14a.5.5 0 0 1-.402.49l-5 1a.502.502 0 0 1-.196 0L5.5 15.01l-4.902.98A.5.5 0 0 1 0 15.5v-14a.5.5 0 0 1 .402-.49l5-1a.5.5 0 0 1 .196 0L10.5.99l4.902-.98a.5.5 0 0 1 .415.103zM10 1.91l-4-.8v12.98l4 .8V1.91zm1 12.98 4-.8V1.11l-4 .8v12.98zm-6-.8V1.11l-4 .8v12.98l4-.8z"
                />
              </svg>{" "}
              {city}
            </span>
            <span className="tour__location d-flex align-item-center gap-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fillRule="currentColor"
                className="bi bi-star"
                viewBox="0 0 16 16"
              >
                <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
              </svg>{" "}
              {avgRating}
              <span>({reviews?.length})</span>
            </span>
          </div>
          <h5 className="tour__rating">
            <Link to={`/tours/${_id}`}>{title}</Link>
          </h5>

          <div className="card__bottom d-flex align-content-center justify-content-between mt-2">
            <h5>
              ${price} <span>/per person</span>
            </h5>

            <button className="btn booking__btn  ">
              <Link
                to={`/tours/${_id}`}
                className="text-white text-decoration-none"
              >
                Book Now
              </Link>
            </button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};

export default TourCard;
