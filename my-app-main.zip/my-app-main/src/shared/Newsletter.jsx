import React from "react";
import maleImg from "../assets/img/male-tourist.png";
import "../style/Newsletter.css";
const Newsletter = () => {
  return <img src={maleImg} alt="" />;
};

export default Newsletter;
