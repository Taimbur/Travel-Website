import React from 'react'
import '../style/CommonSection.css'

import { Col, Row, Container } from 'reactstrap'
const CommonSection = ({ title }) => {

    return (
        <section className="common__section my-4">
            <Container>
                <Row>
                    <Col lg='12'>
                        <h1>{title}</h1>
                    </Col>
                </Row>
            </Container>
        </section>
    );
}

export default CommonSection