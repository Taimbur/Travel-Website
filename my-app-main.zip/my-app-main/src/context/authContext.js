// export const initial_state = null;

import { createContext } from "react";

const AppContext = createContext();
export default AppContext;

// export const reducer = (state, action) => {
//     if (action.type === "User") {
//         return action.payload
//     }
//     return state;
// }




