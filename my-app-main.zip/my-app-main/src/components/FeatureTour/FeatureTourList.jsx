import React from "react";
import TourCard from "../../shared/Tour-Card";
import { Col } from "reactstrap";
// import tourData from "../../assets/data/tours";
import { BASE_URL } from "../../utils/config";
import useFetch from "../../hooks/usefetch";

const FeatureTourList = () => {
  const { data: featuredTour, error } = useFetch(`${BASE_URL}/tours`);


  return (
    <>
      {/* {featuredTour && <h4>Loading...</h4>} */}
      

      {error && <h4>{error} </h4>}
      {!error &&
        featuredTour?.map((tour) => (
          <Col lg="3" className="mb-5 " key={tour._id}>
            {" "}
            <TourCard tour={tour} />
          </Col>
        ))}
    </>
  );
};

export default FeatureTourList;
