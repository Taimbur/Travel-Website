import logo from "../../assets/img/logo.png";
import { Link, useNavigate } from "react-router-dom";
import "./Header.css";
import { useEffect, useRef } from "react";
import { NavLink } from "reactstrap";

const nav__link = [
  {
    path: "/home",
    display: "Home",
  },
  {
    path: "/about-us",
    display: "About",
  },
  {
    path: "/tours",
    display: "Tours",
  },
];

const Header = () => {
  let data1 = window.localStorage.getItem("User");
  const local = () => {
    if (data1) {
      return JSON.parse(data1);
    }
  };
  const navi = useNavigate();

  const headerref = useRef(null);
  const menuref = useRef(null);
  const headerStickyFun = () => {
    window.addEventListener("scroll", () => {
      if (
        document.body.scrollTop > 80 ||
        document.documentElement.scrollTop > 80
      ) {
        headerref.current.classList.add("sticky__header");
      } else {
        headerref.current.classList.remove("sticky__header");
      }
    });
  };
  const logout = () => {
    localStorage.clear();
    navi("/Login");
  };

  useEffect(() => {
    headerStickyFun();
    local();

    return window.removeEventListener("scroll", headerref);
  });

  const toggleMenu = () => {
    menuref.current.classList.toggle("show__menu");
  };
  return (
    <>
      <div className="container-fluid ">
        <header className="header" id="myHeader" ref={headerref}>
          <div className="row">
            {/* logo */}
            <div className="nav__wrapper d-flex ">
              <div className="logo ">
                <img src={logo} alt="header" />
              </div>
              {/* logoend */}

              {/* menu start */}

              <div className="navigation" ref={menuref} onClick={toggleMenu}>
                <ul className="menu d-flex align-item-start gap-5  justify-content-start ">
                  {nav__link.map((item, index) => (
                    <i className="nav__item" key={index}>
                      <Link
                        to={item.path}
                        className={(navClass) =>
                          navClass.isActive ? "active__link" : " "
                        }
                      >
                        {item.display}
                      </Link>
                    </i>
                  ))}
                </ul>
              </div>

              {/* menu end ..........................................*/}

              <div className="nav__left d-flex align-items-center justify-content-center gap-4">
                {data1 ? (
                  <NavLink href="/Login">
                    <button
                      className="btn btn-outline-dark mx-3"
                      onClick={logout}
                    >
                      Logout
                    </button>{" "}
                  </NavLink>
                ) : (
                  <>
                    <NavLink href="/Login">
                      <button className="btn btn-outline-warning">Login</button>{" "}
                    </NavLink>

                    <NavLink href="/Register">
                      <button className="btn btn-outline-warning mx-2">
                        Register
                      </button>{" "}
                    </NavLink>
                  </>
                )}
              </div>

              <span className="mobile__menu" onCanPlay={toggleMenu}>
                <i className="ri-menu-line">---</i>
              </span>

              {data1 && (
                <div className="text-capitalize text-decoration-none">
                  Welcome : <span className="font-weight-bolder">{data1}</span>
                </div>
              )}
            </div>
          </div>
        </header>
      </div>
    </>
  );
};

export default Header;
