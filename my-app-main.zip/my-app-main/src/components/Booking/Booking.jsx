import React, { useContext, useState } from "react";
import "./Booking.css";
import { BASE_URL } from "../../utils/config";
import AppContext from "../../context/authContext";
import {
  Container,
  Row,
  Col,
  Form,
  FormGroup,
  ListGroup,
  ListGroupItem,
} from "reactstrap";
import { useNavigate } from "react-router-dom";

const Booking = ({ tour }) => {
  const user = useContext(AppContext);
  const navi = useNavigate();

  const [booking, setBooking] = useState({
    userId: user._id,
    Email: user.Email,
    Phone: "",
    FullName: "",
    guestSize: "",
    BookAt: "",
  });

  const handleChange = (e) => {
    setBooking((prev) => ({ ...prev, [e.target.id]: e.target.value }));
  };

  const handleClick = async (e) => {
    e.preventDefault();

    try {
      if (!user || user === undefined || user === null) {
        return alert("Login in please");
      }
      const res = await fetch(`${BASE_URL}/booking`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify(booking),
      });
      const result = await res.json();

      if (!res.ok) {
        alert(result.message);
      }

      alert(result.message);
      navi("/thanks");
    } catch (error) {
      alert("something went wrong");
    }
  };
  const { price, avgRating } = tour;

  const service = 10;
  const totalprice = price * booking.guestSize + service;
  return (
    <section>
      <Container className="mt-5 booking">
        <Row>
          <Col
            lg="12"
            className="d-flex text-capitalize justify-content-around gap-3"
          >
            <h2>
              <i>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fillRule="currentColor"
                  className="bi bi-coin"
                  viewBox="0 0 16 16"
                >
                  <path d="M5.5 9.511c.076.954.83 1.697 2.182 1.785V12h.6v-.709c1.4-.098 2.218-.846 2.218-1.932 0-.987-.626-1.496-1.745-1.76l-.473-.112V5.57c.6.068.982.396 1.074.85h1.052c-.076-.919-.864-1.638-2.126-1.716V4h-.6v.719c-1.195.117-2.01.836-2.01 1.853 0 .9.606 1.472 1.613 1.707l.397.098v2.034c-.615-.093-1.022-.43-1.114-.9H5.5zm2.177-2.166c-.59-.137-.91-.416-.91-.836 0-.47.345-.822.915-.925v1.76h-.005zm.692 1.193c.717.166 1.048.435 1.048.91 0 .542-.412.914-1.135.982V8.518l.087.02z" />
                  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                  <path d="M8 13.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zm0 .5A6 6 0 1 0 8 2a6 6 0 0 0 0 12z" />
                </svg>
              </i>{" "}
              ${price}
              <span className="mt-3 person">/per person</span>
            </h2>

            <h5>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fillRule="currentColor"
                className="bi bi-star bg-warning"
                viewBox="0 0 16 16"
              >
                <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
              </svg>{" "}
              {avgRating}{" "}
            </h5>
          </Col>
          <Col lg="12" className="mt-5">
            <h5 className=" text-uppercase ">information</h5>

            <div className="booking__form">
              <Form onSubmit={handleClick}>
                <FormGroup>
                  <input
                    type="text"
                    required
                    placeholder="Your Name"
                    id="FullName"
                    onChange={handleChange}
                  />
                </FormGroup>

                <FormGroup>
                  <input
                    type="text"
                    required
                    placeholder="Phone"
                    id="Phone"
                    onChange={handleChange}
                  />
                </FormGroup>

                <FormGroup className="d-flex gap-1">
                  <input
                    type="date"
                    required
                    id="BookAt"
                    onChange={handleChange}
                  />
                  <input
                    type="text"
                    required
                    placeholder="Guest"
                    id="guestSize"
                    onChange={handleChange}
                  />
                </FormGroup>
              </Form>

              <div className="booking__bottom ">
                <ListGroup>
                  <ListGroupItem className="border-0 px-0">
                    <h5>${price} x 1 peson </h5>{" "}
                    <span className="booking-span">${price}</span>
                  </ListGroupItem>

                  <ListGroupItem className="border-0 px-0">
                    <h5>${price} service charge </h5>{" "}
                    <span className="booking-span">${service}</span>
                  </ListGroupItem>

                  <ListGroupItem className="border-0 px-0 total">
                    <h5 className="total">${price} Total </h5>{" "}
                    <span className="booking-span">${totalprice}</span>
                  </ListGroupItem>
                </ListGroup>
                <button
                  className="btn btn-warning w-100 mt-2 my-4 py-3 rounded-5 text-white"
                  type="submit"
                  onClick={handleClick}
                >
                  {" "}
                  Submit{" "}
                </button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Booking;
