import React from "react";
import ava01 from "../../assets/img/ava-1.jpg";
import ava02 from "../../assets/img/ava-2.jpg";
import ava03 from "../../assets/img/ava-3.jpg";

const Tetimonals = () => {
  return (
    <div id="carouselExampleDark" className="carousel carousel-dark slide">
      <div className="carousel-indicators">
        <button
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide-to="0"
          className="active"
          aria-current="true"
          aria-label="Slide 1"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide-to="1"
          aria-label="Slide 2"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide-to="2"
          aria-label="Slide 3"
        ></button>
      </div>
      <div className="carousel-inner">
        <div className="carousel-item active" data-bs-interval="10000">
          <div className="testimonial py-4 px-3">
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, ut
              dolorum, harum blanditiis expedita facilis dolorem vero neque
              consectetur repellendus explicabo eligendi impedit illum sed. Rem
              iste quas maiores accusantium.
            </p>

            <div className=" d-flex align-content-center justify-content-center  g-4 mt-3">
              <img src={ava01} alt="" className="w-25 h-25 rounded-4" />
              <div>
                <h5 className="mb-0 mt-3 px-2"> khan ismail</h5>
                <p>customer</p>
              </div>
            </div>
          </div>
        </div>
        <div className="carousel-item" data-bs-interval="2000">
          <div className="testimonial py-4 px-3">
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, ut
              dolorum, harum blanditiis expedita facilis dolorem vero neque
              consectetur repellendus explicabo eligendi impedit illum sed. Rem
              iste quas maiores accusantium.
            </p>

            <div className=" d-flex align-content-center justify-content-center g-4 mt-3">
              <img src={ava02} alt="" className="w-25 h-25 rounded-4" />
              <div>
                <h5 className="mb-0 mt-3 px-2"> alex zendra</h5>
                <p>customer</p>
              </div>
            </div>
          </div>
        </div>
        <div className="carousel-item">
          <div className="testimonial py-4 px-3">
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, ut
              dolorum, harum blanditiis expedita facilis dolorem vero neque
              consectetur repellendus explicabo eligendi impedit illum sed. Rem
              iste quas maiores accusantium.
            </p>

            <div className=" d-flex align-content-center justify-content-center g-4 mt-3">
              <img src={ava03} alt="" className="w-25 h-25 rounded-4" />
              <div>
                <h5 className="mb-0 mt-3 px-2"> john abrehim</h5>
                <p>customer</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button
        className="carousel-control-prev"
        type="button"
        data-bs-target="#carouselExampleDark"
        data-bs-slide="prev"
      >
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
      </button>
      <button
        className="carousel-control-next"
        type="button"
        data-bs-target="#carouselExampleDark"
        data-bs-slide="next"
      >
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
      </button>
    </div>
  );
};

export default Tetimonals;
