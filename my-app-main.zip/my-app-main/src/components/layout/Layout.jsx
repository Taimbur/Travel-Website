import React from "react";
import Footer from "./../footer/Footer";
import Router from "../../router/Router";

<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css"
/>

const Layout = () => {
  return (
    <>
      
      <Router />
      <Footer />
    </>
  );
};

export default Layout;

 

 