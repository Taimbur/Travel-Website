import React from "react";
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";
import galleryImages from "./ImageGallery";
const Masonryy = () => {
  return (
    <ResponsiveMasonry columnsCountBreakPoints={{ 350: 1, 750: 2, 900: 3 }}>
      <Masonry gutter="1rem">
        {galleryImages.map((item, index) => (
          <img src={item} alt="" key={index} className="masonry__img" />
        ))}
      </Masonry>
    </ResponsiveMasonry>
  );
};

export default Masonryy;
