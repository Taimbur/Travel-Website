import { useState } from 'react';
import './App.css';
import Layout from './components/layout/Layout';
import AppContext from './context/authContext';
import Header from './components/header/Header';


function App() {

  const [user, setUser] = useState(false)
  const loadData = (actionType, payload) => {
    switch (actionType) {
      case 'Add_user':
        setUser([payload.newUser]);

        return;
      case 'Logout_user':
        setUser([null]);

        return;

      default:
        return
    }
  }



  return (<>
    <AppContext.Provider value={{ user, loadData }}>
      <Header />
      <Layout />
    </AppContext.Provider>

  </>

  );

}

export default App;
